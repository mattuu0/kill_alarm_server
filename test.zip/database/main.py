from database.setting import session
from database.models import User,Friend,migrate

migrate()

