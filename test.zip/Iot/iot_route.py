from fastapi import APIRouter,Request
from pydantic import BaseModel

router = APIRouter()

#IOTデバイス
class IotDevice(BaseModel):
    deviceid : str

#デバイスを登録する
@app.post("/pair_iot")
async def pair_iot(request: Request,deviceData : IotDevice,credentials: JwtAuthorizationCredentials = Security(access_security)):
    subjects = dict(credentials.subject)
    userid = subjects["userid"]                                     #ユーザーID取得
    access_tokenid = subjects["tokenid"]                            #アクセストークンID

    return_result = {"msgtype" : "","message" : "","msgcode" : ""}
    #アクセストークン検証
    if token_util.verify_access_token(userid,access_tokenid):
        #ユーザーが既に登録しているか
        already_paierd,device = get_device_from_userid(userid)

        if already_paierd:
            return_result["msgcode"] = "11133"
            return_result["message"] = "You have already paired device"
            return_result["msgtype"] = "Error_Message"
            return return_result

        #登録する
        is_success,device = pair_device(str(deviceData.deviceid),userid)

        #成功したらデバイスIDを返す
        if is_success:
            return_result["msgcode"] = "11134"
            return_result["message"] = "Device registration successful"
            return_result["msgtype"] = "Success_Message"
            return_result["deviceid"] = device.deviceid
            return return_result
        else:
            return_result["msgcode"] = "11135"
            return_result["message"] = "Device registration failure"
            return_result["msgtype"] = "Error_Message"

            return return_result
    else:
        raise HTTPException(status_code=401, detail="invalid token")

#デバイス登録解除
@app.post("/unpair_iot")
async def unpair_iot(request: Request,credentials: JwtAuthorizationCredentials = Security(access_security)):
    subjects = dict(credentials.subject)
    userid = subjects["userid"]                                     #ユーザーID取得
    access_tokenid = subjects["tokenid"]                            #アクセストークンID

    return_result = {"msgtype" : "","message" : "","msgcode" : ""}
    #アクセストークン検証
    if token_util.verify_access_token(userid,access_tokenid):
        #ユーザーが既に登録しているか
        already_paierd,device = get_device_from_userid(userid)

        #登録していなかったら戻る
        if not already_paierd:
            return_result["msgcode"] = "11138"
            return_result["message"] = "No device paired"
            return_result["msgtype"] = "Error_Message"
            return return_result

        #登録解除する
        is_success,device = unpair_device(userid)

        #成功したらデバイスIDを返す
        if is_success:
            return_result["msgcode"] = "11136"
            return_result["message"] = "success to unpair device"
            return_result["msgtype"] = "Success_Message"
            return_result["deviceid"] = device.deviceid
            return return_result
        else:
            return_result["msgcode"] = "11137"
            return_result["message"] = "failed to unpair device"
            return_result["msgtype"] = "Error_Message"

            return return_result
    else:
        raise HTTPException(status_code=401, detail="invalid token")
