from Iot.auth import register_device

register_device()