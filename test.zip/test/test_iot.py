import websocket
import json
import time
 
device_data = {
    "deviceToken": "eyJhbGciOiJIUzUxMiIsInR5cCI6IkpXVCJ9.eyJkZXZpY2VpZCI6ImE2MDYzZDBjMzMwZGYxYmM4MmU3YzVkYWI3MDEzZGQ2NWM1NDdjYjI5MTNhMTViM2M4NmRlYWY0NTI5MzVjOTE1Njg4MGU4YjI3MmFiMmJlNjljMzYwMmQ1Y2YzMGM4OWRmMDRkMzE3ZTkxMjJjNTBiMzQ1OTA5NTVhNTk5MmQ0IiwidG9rZW5pZCI6IjBkYTdmZTQyLWYyN2ItNGFiMy1iYWMyLThlMTZkMWFjOGEyMSJ9._Y-1q0NM0xBO4Lthe03Xw2R5fk2qnPD8N6HrA5XbcHX9aXjfGtLgKnUI08Am2l-E-hk-uNkXDJqG_uJQwwdnCw",
    "deviceid": "a6063d0c330df1bc82e7c5dab7013dd65c547cb2913a15b3c86deaf452935c9156880e8b272ab2be69c3602d5cf30c89df04d317e9122c50b34590955a5992d4"
}

def on_message(wsapp, message):
    print(message)

def on_open(wsapp):
    auth_data = {
        "msgtype": 'authToken',
        "token" : device_data["deviceToken"]
    }

    wsapp.send(json.dumps(auth_data))

def on_close_server(wsapp):
    print("Closed")
    time.sleep(5)
    connect_server()

def connect_server():
    wsapp = websocket.WebSocketApp("ws://127.0.0.1:8000/iotws", on_message=on_message,on_open=on_open,on_close=on_close_server)

    wsapp.run_forever()

connect_server()