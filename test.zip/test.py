from friends.friend import Friend,create_friend
from server_auth.database import create_user

user1 = create_user("test1","password")
user2 = create_user("test2","password")

print(create_friend(user1.userid,user2.userid).created_at.timestamp())